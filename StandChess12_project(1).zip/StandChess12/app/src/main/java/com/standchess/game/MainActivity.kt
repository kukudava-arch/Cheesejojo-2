package com.standchess.game

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StandChessScreen() }
    }
}

private data class ChessPiece(val symbol: String, val white: Boolean, val kind: Char)

@Composable
private fun StandChessScreen() {
    val board = remember { mutableStateListOf<ChessPiece?>().apply { repeat(64) { add(null) } } }
    var selected by remember { mutableIntStateOf(-1) }
    var message by remember { mutableStateOf("Выберите фигуру") }
    var turnWhite by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        val backWhite = listOf('R','N','B','Q','K','B','N','R')
        val backBlack = listOf('R','N','B','Q','K','B','N','R')
        fun symbol(kind: Char, white: Boolean) = when (kind) {
            'K' -> if (white) "♔" else "♚"
            'Q' -> if (white) "♕" else "♛"
            'R' -> if (white) "♖" else "♜"
            'B' -> if (white) "♗" else "♝"
            'N' -> if (white) "♘" else "♞"
            else -> if (white) "♙" else "♟"
        }
        for (c in 0..7) {
            board[c] = ChessPiece(symbol(backBlack[c], false), false, backBlack[c])
            board[8 + c] = ChessPiece("♟", false, 'P')
            board[48 + c] = ChessPiece("♙", true, 'P')
            board[56 + c] = ChessPiece(symbol(backWhite[c], true), true, backWhite[c])
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().background(Color(0xFF101318)).padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("STAND CHESS 1.2", color = Color(0xFFE8D5A8), fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Демо доски • локальная партия", color = Color.LightGray, fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))
        Text(message, color = Color.White, fontSize = 16.sp)
        Spacer(Modifier.height(12.dp))

        Column(modifier = Modifier.fillMaxWidth().aspectRatio(1f)) {
            for (row in 0..7) {
                Row(modifier = Modifier.weight(1f)) {
                    for (col in 0..7) {
                        val index = row * 8 + col
                        val piece = board[index]
                        val base = if ((row + col) % 2 == 0) Color(0xFFE4D7B8) else Color(0xFF657B70)
                        val cellColor = if (selected == index) Color(0xFFD7A84B) else base
                        Box(
                            modifier = Modifier.weight(1f).fillMaxHeight()
                                .background(cellColor)
                                .clickable {
                                    if (selected == -1) {
                                        if (piece != null && piece.white == turnWhite) selected = index
                                        else message = "Выберите свою фигуру"
                                    } else {
                                        val fromPiece = board[selected]
                                        if (fromPiece != null && (piece == null || piece.white != fromPiece.white)) {
                                            if (piece?.kind == 'K') {
                                                board[index] = fromPiece
                                                board[selected] = null
                                                message = if (fromPiece.white) "Белые захватили короля! Победа белых!" else "Чёрные захватили короля! Победа чёрных!"
                                            } else {
                                                board[index] = fromPiece
                                                board[selected] = null
                                                turnWhite = !turnWhite
                                                message = if (turnWhite) "Ход белых" else "Ход чёрных"
                                            }
                                        } else {
                                            message = "Нельзя переместить туда"
                                        }
                                        selected = -1
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (piece != null) Text(piece.symbol, fontSize = 30.sp, color = if (piece.white) Color.White else Color(0xFF171717))
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = {
                for (i in 0 until 64) board[i] = null
                val whiteBack = listOf("♖","♘","♗","♕","♔","♗","♘","♖")
                val blackBack = listOf("♜","♞","♝","♛","♚","♝","♞","♜")
                for (c in 0..7) {
                    board[c] = ChessPiece(blackBack[c], false, "RNBQKBNR"[c])
                    board[8+c] = ChessPiece("♟", false, 'P')
                    board[48+c] = ChessPiece("♙", true, 'P')
                    board[56+c] = ChessPiece(whiteBack[c], true, "RNBQKBNR"[c])
                }
                selected = -1; turnWhite = true; message = "Новая партия • ход белых"
            }, shape = RoundedCornerShape(12.dp)) { Text("Новая партия") }
            OutlinedButton(onClick = { selected = -1; message = "Выбор сброшен" }) { Text("Сброс выбора") }
        }
        Spacer(Modifier.height(8.dp))
        Text("Прототип: пока без полного шахматного движка и способностей Стендов.", color = Color.Gray, fontSize = 11.sp)
    }
}
